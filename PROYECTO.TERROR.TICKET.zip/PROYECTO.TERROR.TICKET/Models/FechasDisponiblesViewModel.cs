﻿public class FechasDisponiblesViewModel
{
    public List<DateTime> Fechas { get; set; }

    public FechasDisponiblesViewModel()
    {
        // Inicializa la lista de fechas disponibles con las fechas deseadas
        Fechas = new List<DateTime>
        {
            new DateTime(2023, 10, 15), // Ejemplo de fecha
            new DateTime(2023, 10, 20), // Ejemplo de fecha
            // Agrega más fechas según tu necesidad
        };
    }
}
