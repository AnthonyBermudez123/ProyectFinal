﻿using System;
using System.Collections.Generic;

namespace TuProyecto.Models
{
    public class CompraEntradasViewModel
    {
        public int CantidadEntradas { get; set; }
        public DateTime Fecha { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public int Edad { get; set; }

        // Propiedad para las fechas disponibles
        public List<DateTime> FechasDisponibles { get; set; }
    }
}

