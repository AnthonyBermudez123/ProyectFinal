﻿namespace TuProyecto.Models
{
    public class CompraEntradasViewModel
    {
        // Propiedades para los datos de la compra
        public int CantidadEntradas { get; set; }
        public DateTime Fecha { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public int Edad { get; set; }

        // Otras propiedades relacionadas con la compra, si es necesario
    }
}
