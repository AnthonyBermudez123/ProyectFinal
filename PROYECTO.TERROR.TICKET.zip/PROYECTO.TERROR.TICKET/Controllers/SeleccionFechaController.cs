﻿using Microsoft.AspNetCore.Mvc;

public class SeleccionFechaController : Controller
{
    // Otras acciones...

    // Acción para mostrar la página de selección de fecha
    public IActionResult Index()
    {
        return View(); // Debes tener una vista correspondiente a esta acción
    }
}
