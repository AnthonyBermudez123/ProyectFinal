﻿using Microsoft.AspNetCore.Mvc;

public class CompraEntradasController : Controller
{
    // Otras acciones del controlador...

    // Acción para mostrar la página de compra de entradas
    public IActionResult Index()
    {
        return View("CompraEntradas"); // Debe devolver la vista "CompraEntradas.cshtml"
    }
}
