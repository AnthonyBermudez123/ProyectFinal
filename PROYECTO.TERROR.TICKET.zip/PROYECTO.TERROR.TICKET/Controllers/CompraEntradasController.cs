﻿using Microsoft.AspNetCore.Mvc;

namespace TuProyecto.Controllers
{
    public class CompraEntradasController : Controller
    {
        

        // Acción para mostrar la página de compra de entradas
        public IActionResult CompraEntradas()
        {
            return View("CompraEntradas"); //  vista "CompraEntradas.cshtml"
        }

        // Otras acciones del controlador...
    }
}
