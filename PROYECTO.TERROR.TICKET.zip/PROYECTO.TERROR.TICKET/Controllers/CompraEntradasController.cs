﻿using Microsoft.AspNetCore.Mvc;
using TuProyecto.Models;
using System;
using System.Collections.Generic;

namespace TuProyecto.Controllers
{
    public class CompraEntradasController : Controller
    {
        // Acción para mostrar la página de compra de entradas
        public IActionResult CompraEntradas()
        {
            // Aquí creas una instancia de CompraEntradasViewModel y la pasas a la vista
            var compraEntradasViewModel = new CompraEntradasViewModel();

            // Obtener las fechas disponibles y asignarlas al modelo
            compraEntradasViewModel.FechasDisponibles = ObtenerFechasDisponibles();

            return View(compraEntradasViewModel);
        }

        // Acción para procesar la compra de entradas
        [HttpPost]
        public IActionResult RealizarCompra(CompraEntradasViewModel modelo)
        {
            // Tu lógica para procesar la compra aquí

            // Redirige al usuario a la vista de confirmación
            return View("RealizarCompra", modelo); // Reemplaza "RealizarCompra" con el nombre correcto de tu vista de confirmación si es diferente
        }

        // Método para obtener las fechas disponibles
        private List<DateTime> ObtenerFechasDisponibles()
        {
            // Implementa la lógica para obtener las fechas disponibles desde tu base de datos o donde las tengas almacenadas
            var fechas = new List<DateTime>
            {
                new DateTime(2023, 10, 15),
                new DateTime(2023, 10, 16),
                new DateTime(2023, 10, 22),
                // Agrega más fechas según tus necesidades
            };

            return fechas;
        }
    }
}

