﻿using Microsoft.AspNetCore.Mvc;

namespace TuProyecto.Controllers
{
    public class CompraEntradasController : Controller
    {
        // Otras acciones del controlador...

        // Acción para mostrar la página de compra de entradas
        public IActionResult CompraEntradas()
        {
            return View(); // Buscará la vista "CompraEntradas.cshtml" en la carpeta "Views"
        }

        // Otras acciones del controlador...
    }
}
