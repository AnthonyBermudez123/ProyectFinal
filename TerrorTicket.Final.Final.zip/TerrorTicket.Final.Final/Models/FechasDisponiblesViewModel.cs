﻿public class FechasDisponiblesViewModel
{
    public List<DateTime> Fechas { get; set; }

    public FechasDisponiblesViewModel()
    {
        
        Fechas = new List<DateTime>
        {
            new DateTime(2023, 10, 15), 
            new DateTime(2023, 10, 20), 
            
        };
    }
}
