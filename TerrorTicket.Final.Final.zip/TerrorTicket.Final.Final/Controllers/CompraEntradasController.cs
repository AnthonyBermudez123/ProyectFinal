﻿using Microsoft.AspNetCore.Mvc;
using TuProyecto.Models;
using System;
using System.Collections.Generic;

namespace TuProyecto.Controllers
{
    public class CompraEntradasController : Controller
    {
        public IActionResult CompraEntradas()
        {
            var compraEntradasViewModel = new CompraEntradasViewModel();
            compraEntradasViewModel.FechasDisponibles = ObtenerFechasDisponibles();

            return View(compraEntradasViewModel);
        }

        [HttpPost]
        public IActionResult RealizarCompra(CompraEntradasViewModel modelo)
        {
            
            modelo.CostoEntrada = CalcularCostoEntrada(modelo.Edad, modelo.CantidadEntradas);

            return View("RealizarCompra", modelo);
        }

        private List<DateTime> ObtenerFechasDisponibles()
        {
            var fechas = new List<DateTime>
            {
                new DateTime(2023, 10, 15),
                new DateTime(2023, 10, 16),
                new DateTime(2023, 10, 22),
            };

            return fechas;
        }

        
        private decimal CalcularCostoEntrada(int edad, int cantidadEntradas)
        {
            
            if (edad < 5)
            {
                return 2.50M * cantidadEntradas;
            }
            else if (edad >= 5 && edad <= 18)
            {
                return 4.00M * cantidadEntradas;
            }
            else if (edad >= 18 && edad <= 55)
            {
                return 6.00M * cantidadEntradas;
            }
            else if (edad > 65)
            {
                return 2.00M * cantidadEntradas;
            }

            
            return 0.0M;
        }
    }
}
