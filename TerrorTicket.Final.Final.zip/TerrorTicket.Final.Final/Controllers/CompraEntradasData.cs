﻿public class CompraEntradasData
{
    public string Nombre { get; set; }
    public string Correo { get; set; }
    public int Edad { get; set; }
    public int CantidadEntradas { get; set; }
    public DateTime Fecha { get; set; }
    public decimal CostoEntrada { get; set; }
}
