﻿using Microsoft.AspNetCore.Mvc;
using TuProyecto.Models;
using System;
using System.Collections.Generic;



namespace TuProyecto.Controllers
{
    public class CompraEntradasController : Controller
    {
        
        public IActionResult CompraEntradas()
        {
            
            var compraEntradasViewModel = new CompraEntradasViewModel();

            
            compraEntradasViewModel.FechasDisponibles = ObtenerFechasDisponibles();

            return View(compraEntradasViewModel);
        }

        
        [HttpPost]
        public IActionResult RealizarCompra(CompraEntradasViewModel modelo)
        {
            

            
            return View("RealizarCompra", modelo); 
        }

        private List<DateTime> ObtenerFechasDisponibles()
        {
            
            var fechas = new List<DateTime>
            {
                new DateTime(2023, 10, 15),
                new DateTime(2023, 10, 16),
                new DateTime(2023, 10, 22),
                
            };

            return fechas;
        }

    }
}

