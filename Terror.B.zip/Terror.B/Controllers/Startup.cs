﻿namespace TerrorTicket.Final.Final.Controllers
{
    public class Startup
    {
    }
}
