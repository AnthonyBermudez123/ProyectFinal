﻿using Microsoft.AspNetCore.Mvc;
using TuProyecto.Models;
using System;
using System.Collections.Generic;
using Dapper;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace TuProyecto.Controllers
{
    public class CompraEntradasController : Controller
    {
        private readonly string _connectionString;

        public CompraEntradasController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IActionResult CompraEntradas()
        {
            var compraEntradasViewModel = new CompraEntradasViewModel();
            compraEntradasViewModel.FechasDisponibles = ObtenerFechasDisponibles();

            return View(compraEntradasViewModel);
        }

        [HttpPost]
        public IActionResult RealizarCompra(CompraEntradasViewModel modelo)
        {
            modelo.CostoEntrada = CalcularCostoEntrada(modelo.Edad, modelo.CantidadEntradas);

            using (IDbConnection dbConnection = new SqlConnection(_connectionString))
            {
                string insertQuery = "INSERT INTO CompraEntradasA (Nombre, Correo, Edad, CantidadEntradas, Fecha, CostoEntrada) " +
                    "VALUES (@Nombre, @Correo, @Edad, @CantidadEntradas, @Fecha, @CostoEntrada)";


                dbConnection.Execute(insertQuery, new
                {
                    modelo.Nombre,
                    modelo.Correo,
                    modelo.Edad,
                    modelo.CantidadEntradas,
                    Fecha = DateTime.Now, 
                    modelo.CostoEntrada
                });
            }

            return View("RealizarCompra", modelo);
        }

        private List<DateTime> ObtenerFechasDisponibles()
        {
            var fechas = new List<DateTime>
            {
                new DateTime(2023, 11, 8),
                new DateTime(2023, 11, 9),
                new DateTime(2023, 11, 10),
                new DateTime(2023, 11, 11), 
                new DateTime(2023, 11, 12),
                new DateTime(2023, 11, 13),
                new DateTime(2023, 11, 14),
                new DateTime(2023, 11, 15),
                new DateTime(2023, 11, 16),
                new DateTime(2023, 11, 17),
                new DateTime(2023, 11, 18),
                new DateTime(2023, 11, 19),
                new DateTime(2023, 11, 20),
                new DateTime(2023, 11, 21),
                new DateTime(2023, 11, 22),
                new DateTime(2023, 11, 23),
                new DateTime(2023, 11, 24),
                new DateTime(2023, 11, 25),
                new DateTime(2023, 11, 26),
                new DateTime(2023, 11, 27),
                new DateTime(2023, 11, 28),
                new DateTime(2023, 11, 29),
                new DateTime(2023, 11, 30),
                new DateTime(2023, 12, 1),
                new DateTime(2023, 12, 2),
                new DateTime(2023, 12, 3),
                new DateTime(2023, 12, 4),
                new DateTime(2023, 12, 5),
                new DateTime(2023, 12, 6),
                new DateTime(2023, 12, 7),
                new DateTime(2023, 12, 8),
                new DateTime(2023, 12, 9),
                new DateTime(2023, 12, 10),
                new DateTime(2023, 12, 11),
                new DateTime(2023, 12, 12),
                new DateTime(2023, 12, 13),
                new DateTime(2023, 12, 14),
                new DateTime(2023, 12, 15),
                new DateTime(2023, 12, 16),
                new DateTime(2023, 12, 17),
                new DateTime(2023, 12, 18),
                new DateTime(2023, 12, 19),
                new DateTime(2023, 12, 20),
                new DateTime(2023, 12, 21),
                new DateTime(2023, 12, 22),
                new DateTime(2023, 12, 23),
                new DateTime(2023, 12, 24),
                new DateTime(2023, 12, 25),
                new DateTime(2023, 12, 26),
                new DateTime(2023, 12, 27),
                new DateTime(2023, 12, 28),
                new DateTime(2023, 12, 29),
                new DateTime(2023, 12, 30),
                new DateTime(2023, 12, 31),


            };

            return fechas;
        }

        private decimal CalcularCostoEntrada(int edad, int cantidadEntradas)
        {
            if (edad < 5)
            {
                return 2.50M * cantidadEntradas;
            }
            else if (edad >= 5 && edad <= 18)
            {
                return 4.00M * cantidadEntradas;
            }
            else if (edad >= 18 && edad <= 55)
            {
                return 6.00M * cantidadEntradas;
            }
            else if (edad >= 65)
            {
                return 2.00M * cantidadEntradas;
            }

            return 0.0M;
        }
    }
}
