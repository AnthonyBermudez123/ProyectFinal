﻿namespace Proyecto_Final_TerrorTicket.Data
{
    public class DatosDeEntradas
    {
    }
}
