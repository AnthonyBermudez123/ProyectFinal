﻿using System;

namespace TuProyecto.Models
{
    public class Entrada
    {
        public int Id { get; set; }
        public string Categoria { get; set; }
        public decimal Precio { get; set; }
    }
}
