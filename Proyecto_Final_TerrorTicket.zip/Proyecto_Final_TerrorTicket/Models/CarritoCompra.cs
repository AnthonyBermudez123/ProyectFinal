﻿using System.Collections.Generic;
using System.Linq;

namespace TuProyecto.Models
{
    public class CarritoCompra
    {
        private List<Entrada> entradasEnCarrito = new List<Entrada>();

        public void AgregarEntradaAlCarrito(Entrada entrada)
        {
            entradasEnCarrito.Add(entrada);
        }

        public void EliminarEntradaDelCarrito(int entradaId)
        {
            var entradaAEliminar = entradasEnCarrito.FirstOrDefault(e => e.Id == entradaId);
            if (entradaAEliminar != null)
            {
                entradasEnCarrito.Remove(entradaAEliminar);
            }
        }

        public List<Entrada> ObtenerEntradasEnCarrito()
        {
            return entradasEnCarrito;
        }

        public decimal CalcularTotal()
        {
            return entradasEnCarrito.Sum(e => e.Precio);
        }
    }
}
