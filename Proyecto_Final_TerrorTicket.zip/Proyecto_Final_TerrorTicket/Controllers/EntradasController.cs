﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using TuProyecto.Models; 

namespace TuProyecto.Controllers
{
    public class EntradasController : Controller
    {
        private List<Entrada> entradasDisponibles = new List<Entrada>
        {
            new Entrada { Id = 1, Categoria = "Niños", Precio = 10.00m },
            new Entrada { Id = 2, Categoria = "Adultos", Precio = 20.00m },
            new Entrada { Id = 3, Categoria = "Adultos Mayores", Precio = 15.00m }
        };

        private CarritoCompra carrito = new CarritoCompra();

        public ActionResult Index()
        {
            return View(entradasDisponibles);
        }

        public ActionResult AgregarAlCarrito(int entradaId)
        {
            var entradaSeleccionada = entradasDisponibles.FirstOrDefault(e => e.Id == entradaId);

            if (entradaSeleccionada != null)
            {
                carrito.AgregarEntradaAlCarrito(entradaSeleccionada);
            }

            return RedirectToAction("CarritoCompra");
        }


  
    }
}
